# -*- encoding: utf-8 -*-

from twitch.oauth.helix import scopes
